package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BbsDAO {
	Connection con = null;
	private ResultSet rs;
	
	String DBdriver = "org.postgresql.Driver";
	String DBurl = "jdbc:postgresql://localhost:5432/webapp";
	
	void connect() {

		try {
			Class.forName(DBdriver);
			con = DriverManager.getConnection(DBurl, "postgres", "1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public String getDate() {
		connect();
		String sql = "SELECT current_date";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	public int getNext() {
		connect();
		String sql = "SELECT bbsID FROM bbs ORDER BY bbsID DESC";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; //ù��° �Խù��� ���
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //�����ͺ��̽� ȣ��
	}
	public int write(String bbsTitle, String m_id, String bbsContent) {
		connect();
		String sql = "INSERT INTO bbs VALUES (?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, bbsTitle);
			pstmt.setString(3, m_id);
			pstmt.setString(4, bbsContent);
			pstmt.setInt(5, 1);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public ArrayList<Bbs> getList(int pageNumber) {
		connect();
		String sql = "SELECT * FROM bbs WHERE bbsID < ? AND bbsAvailabe = 1 ORDER BY bbsID DESC LIMIT 10";
		ArrayList<Bbs> list = new ArrayList<Bbs>();
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,  getNext() - (pageNumber -1) * 10);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Bbs bbs = new Bbs();
				bbs.setBbsID(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setM_id(rs.getString(3));
				bbs.setBbsContent(rs.getString(4));
				bbs.setBbsAvailable(rs.getInt(5));
				list.add(bbs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public boolean nextPage(int pageNumber) {
		connect();
		String sql = "SELECT * FROM bbs where bbsID < ? AND bbsAvailabe = 1 ORDER BY bbsID DESC LIMIT 10";
	
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,  getNext() - (pageNumber -1) * 10);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; //�����ͺ��̽� ȣ��
	}
	public Bbs getBbs(int bbsID) {
		connect();
		String sql = "SELECT*FROM bbs WHERE bbsID = ?";
	
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,bbsID);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				Bbs bbs = new Bbs();
				bbs.setBbsID(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setM_id(rs.getString(3));
				bbs.setBbsContent(rs.getString(4));
				bbs.setBbsAvailable(rs.getInt(5));
				return bbs;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null; //�����ͺ��̽� ȣ��
	}
	}

