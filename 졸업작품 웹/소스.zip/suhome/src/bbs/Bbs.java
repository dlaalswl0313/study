package bbs;

public class Bbs {
	private int bbsID;
	private String bbsTitle;
	private String m_id;
	
	private String bbsContent;
	private int bbsAvailabe;
	
	public int getBbsID() {
		return bbsID;
	}
	public void setBbsID(int bbsID) {
		this.bbsID = bbsID;
	}
	public String getBbsTitle() {
		return bbsTitle;
	}
	public void setBbsTitle(String bbsTitle) {
		this.bbsTitle = bbsTitle;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getBbsContent() {
		return bbsContent;
	}
	public void setBbsContent(String bbsContent) {
		this.bbsContent = bbsContent;
	}
	public int getBbsAvailabe() {
		return bbsAvailabe;
	}
	public void setBbsAvailable(int bbsAvailable) {
		this.bbsAvailabe = bbsAvailable;
	}

	

}
