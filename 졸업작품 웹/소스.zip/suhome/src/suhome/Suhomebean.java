package suhome;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Suhomebean {
	Connection con = null;
	PreparedStatement pstmt = null;

	String DBdriver = "org.postgresql.Driver";
	String DBurl = "jdbc:postgresql://localhost:5432/webapp";

	void connect() {

		try {
			Class.forName(DBdriver);
			con = DriverManager.getConnection(DBurl, "postgres", "1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void disConnect() {
		try {
			if (pstmt != null) {
				pstmt.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int login(String m_id, String m_password) {
		connect();

		String sql = "select m_password FROM suhome WHERE m_id = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, m_id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				if(rs.getString(1).equals(m_password))
					return 1; //�α��μ���
				else
					return 0; //��й�ȣ ����ġ
			}
			return -1; //���̵� ����

	} catch (Exception e) {
		e.printStackTrace();
	}
		return -2; // �����ͺ��̽� ȣ��
	

}
	public int join(Suhome suhome) {
		connect();
		
		String sql = "INSERT INTO suhome VALUES (?,?,?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,suhome.getM_name());
			pstmt.setString(2,suhome.getM_id());
			pstmt.setString(3,suhome.getM_password());
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}