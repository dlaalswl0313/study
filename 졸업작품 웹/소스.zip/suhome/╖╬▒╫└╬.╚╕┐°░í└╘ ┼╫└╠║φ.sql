﻿CREATE TABLE suhome
(
  m_name character varying(20) NOT NULL,
  m_id character varying(20) NOT NULL,
  m_password character varying(20) NOT NULL,
  CONSTRAINT suhome_pkey PRIMARY KEY (m_id)
)