﻿CREATE TABLE bbs
(
  bbsid integer NOT NULL,
  bbstitle character varying(50) NOT NULL,
  m_id character varying(20) NOT NULL,
  bbscontent character varying(2048),
  bbsavailabe integer,
  CONSTRAINT bbs_pkey PRIMARY KEY (bbsid)
)